<?php
/*
Plugin Name: MI POS MOBILE BARCODE
Plugin URI: https://example.com
Description: A barcode scanning plugin for WooCommerce integration.
Version: 1.0.0
Author: Criszoom
Author URI: https://example.com
License: GPL2
*/

// Plugin code here
?>