=== MI POS MOBILE BARCODE ===
Contributors: Criszoom
Tags: pos, barcode, mobile, woocommerce
Requires at least: 5.0
Tested up to: 5.8
Requires PHP: 7.0
License: GPL2

== Description ==
This is a POS barcode scanning plugin for WooCommerce integration.
It supports inventory management and mobile app connection.

== Installation ==
1. Upload the plugin to your WordPress plugins directory.
2. Activate the plugin in the WordPress admin.

== Changelog ==
= 1.0.0 =
* Initial release.
